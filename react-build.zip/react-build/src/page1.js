'use strict';

var React = require('react');
var ReactRouter = require('react-router');
var Link = ReactRouter.Link;


module.exports = React.createClass({
    render: function() {
        return (
            <div>
                <h5>Wonderful! This is page 1</h5>
            </div>
        )
    }
})
